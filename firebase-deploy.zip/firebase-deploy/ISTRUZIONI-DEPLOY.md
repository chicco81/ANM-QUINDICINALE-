# 🚀 GUIDA DEPLOY — ANM Turni su Firebase Hosting

## Cosa ti serve
- Un computer (Windows, Mac o Linux)
- Node.js installato → https://nodejs.org (scarica la versione LTS)
- Account Google (già ce l'hai se usi Firebase)

---

## PASSO 1 — Installa Firebase CLI

Apri il terminale (su Mac: Terminale, su Windows: PowerShell o cmd) e digita:

```
npm install -g firebase-tools
```

Verifica che sia installato:
```
firebase --version
```

---

## PASSO 2 — Accedi con il tuo account Google

```
firebase login
```

Si aprirà il browser per fare il login con Google. Usa lo stesso account con cui hai creato il progetto Firebase.

---

## PASSO 3 — Copia i file nella cartella

Crea una cartella sul tuo PC, ad esempio:
- `C:\anm-turni\` (Windows)
- `/Users/tuonome/anm-turni/` (Mac)

Dentro questa cartella metti:
```
anm-turni/
├── firebase.json        ← il file firebase.json allegato
├── .firebaserc          ← il file .firebaserc allegato
└── public/
    └── index.html       ← il file anm-turni.html rinominato index.html
```

---

## PASSO 4 — Collega al tuo progetto Firebase

Entra nella cartella:
```
cd C:\anm-turni        (Windows)
cd ~/anm-turni         (Mac)
```

Collega al progetto (se non lo fai automaticamente con .firebaserc):
```
firebase use anm-operatore
```

Se non trovi il progetto, elenca i tuoi:
```
firebase projects:list
```

E usa l'ID del tuo progetto:
```
firebase use <ID-PROGETTO>
```

---

## PASSO 5 — Pubblica online! 🎉

```
firebase deploy --only hosting
```

Dopo qualche secondo vedrai:
```
✔  Deploy complete!

Project Console: https://console.firebase.google.com/project/anm-operatore/overview
Hosting URL: https://anm-operatore.web.app
```

L'app sarà accessibile da **https://anm-operatore.web.app**

---

## Aggiornare l'app in futuro

Ogni volta che hai una versione nuova dell'app (nuovo index.html), sostituisci il file in `public/index.html` e rilancia:

```
firebase deploy --only hosting
```

---

## ⚠️ IMPORTANTE — Nota sui dati

I turni e gli autisti sono salvati nel **localStorage del browser** del tuo telefono.

Questo significa:
- Se apri l'app su un altro telefono, i dati NON ci sono
- Se cancelli i dati del browser, i dati spariscono

**Soluzione consigliata per il futuro:**
Attivare Firebase Realtime Database (già configurato nel progetto) per sincronizzare i dati tra dispositivi. Basta richiedere l'aggiornamento dell'app.

---

## Accesso diretto come app sul telefono (PWA)

Dopo il deploy, apri **https://anm-operatore.web.app** da Safari (iPhone) o Chrome (Android):
- **iPhone**: Tocca Condividi → "Aggiungi a schermata Home"
- **Android**: Menu Chrome → "Aggiungi a schermata Home"

L'app apparirà come un'icona sul telefono e si aprirà senza browser, come una vera app!

---

## Problemi comuni

**"firebase: command not found"**
→ Node.js non è installato correttamente. Reinstallalo da https://nodejs.org

**"Error: HTTP Error: 403"**
→ Non sei loggato o non hai i permessi. Rifai `firebase login`

**"Error: Project not found"**
→ L'ID del progetto in .firebaserc non corrisponde. Controlla su https://console.firebase.google.com

