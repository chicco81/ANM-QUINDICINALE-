# 🚀 GUIDA DEPLOY — ANM Turni su Firebase
## Con analisi automatica foto/screenshot tramite AI

---

## COSA HAI IN QUESTA CARTELLA

```
firebase-anm/
├── firebase.json          ← configurazione Firebase
├── .firebaserc            ← ID del tuo progetto (da modificare)
├── functions/
│   ├── index.js           ← Cloud Function (backend AI)
│   └── package.json       ← dipendenze Node.js
└── public/
    └── index.html         ← l'app completa
```

---

## STEP 1 — Crea il progetto Firebase (se non ce l'hai)

1. Vai su **https://console.firebase.google.com**
2. Clicca **"Aggiungi progetto"**
3. Dai un nome (es. `anm-turni-napoli`)
4. Disabilita Google Analytics (non serve)
5. Clicca **Crea progetto**
6. **Copia l'ID del progetto** (es. `anm-turni-napoli-abc12`)

---

## STEP 2 — Attiva piano Blaze (obbligatorio per Cloud Functions)

1. Nel tuo progetto Firebase, clicca **"Spark"** in basso a sinistra
2. Seleziona **"Blaze (pay as you go)"**
3. Inserisci carta di credito
4. ⚠️ **Costo reale: quasi zero** — le prime 2 milioni di chiamate/mese
   sono GRATUITE. Per uso personale pagherai €0.

---

## STEP 3 — Installa Firebase CLI sul PC

Apri il Terminale e digita:

```bash
npm install -g firebase-tools
```

Se non hai Node.js: scaricalo da **https://nodejs.org** (versione LTS)

---

## STEP 4 — Login e inizializzazione

```bash
# Login con il tuo account Google
firebase login

# Entra nella cartella del progetto
cd /percorso/dove/hai/salvato/firebase-anm

# Collega al tuo progetto Firebase
firebase use --add
# → seleziona il tuo progetto dall'elenco
```

---

## STEP 5 — Modifica .firebaserc

Apri il file `.firebaserc` e sostituisci `IL-TUO-PROJECT-ID`
con il vero ID del tuo progetto Firebase:

```json
{
  "projects": {
    "default": "anm-turni-napoli-abc12"
  }
}
```

---

## STEP 6 — Ottieni la chiave API di Anthropic (Claude)

1. Vai su **https://console.anthropic.com**
2. Crea un account (gratuito)
3. Vai su **"API Keys"** → **"Create Key"**
4. Copia la chiave (inizia con `sk-ant-...`)
5. ⚠️ Tienila segreta — non condividerla mai

---

## STEP 7 — Salva la chiave API come Secret Firebase

```bash
# Dalla cartella firebase-anm
firebase functions:secrets:set ANTHROPIC_API_KEY
# → incolla la chiave sk-ant-... quando richiesto
# → premi Invio
```

---

## STEP 8 — Installa dipendenze Node.js

```bash
cd functions
npm install
cd ..
```

---

## STEP 9 — Deploy!

```bash
firebase deploy
```

Firebase caricherà:
- ✅ L'app su Firebase Hosting
- ✅ La Cloud Function come backend AI

Al termine vedrai l'URL della tua app:
```
Hosting URL: https://anm-turni-napoli-abc12.web.app
```

---

## STEP 10 — Come funziona dopo il deploy

### Da telefono (Android o iPhone):

**PDF originale ANM:**
→ Apri l'app → Autista → Quindicinale
→ Tocca "Carica foto, screenshot o PDF"
→ Seleziona il PDF
→ I turni vengono estratti automaticamente ✅

**Foto / Screenshot del quindicinale:**
→ Apri l'app → Autista → Quindicinale
→ Tocca "Carica foto, screenshot o PDF"
→ Scatta una foto o seleziona uno screenshot
→ L'AI analizza l'immagine (~5-10 secondi)
→ I turni vengono estratti automaticamente ✅

---

## AGGIORNARE L'APP IN FUTURO

Ogni volta che modifichi `public/index.html` o `functions/index.js`:

```bash
firebase deploy
```

Basta questo comando — l'app si aggiorna in 30 secondi.

---

## INSTALLARE COME APP SUL TELEFONO (PWA)

**iPhone (Safari):**
1. Apri Safari e vai all'URL dell'app
2. Tocca l'icona "Condividi" (quadrato con freccia)
3. Tocca "Aggiungi a schermata Home"
4. L'app appare come icona sul telefono

**Android (Chrome):**
1. Apri Chrome e vai all'URL
2. Tocca i tre puntini in alto a destra
3. Tocca "Aggiungi a schermata Home"

---

## PROBLEMI COMUNI

**"Error: Functions require the Blaze plan"**
→ Attiva il piano Blaze (Step 2)

**"Error: Secret ANTHROPIC_API_KEY not found"**
→ Esegui di nuovo Step 7

**L'analisi AI restituisce errore**
→ Controlla che la chiave Anthropic sia valida
→ Verifica che la foto sia nitida e il testo leggibile

**"Permission denied"**
→ Esegui `firebase login` di nuovo

---

## COSTO STIMATO USO REALE

| Cosa | Costo |
|------|-------|
| Firebase Hosting | GRATIS |
| Cloud Functions (prime 2M/mese) | GRATIS |
| API Anthropic (per immagine) | ~$0.003 (0,003 centesimi) |
| 100 foto/mese | ~$0.30 (30 centesimi) |
| 500 foto/mese | ~$1.50 |

Praticamente gratuito per uso personale.
