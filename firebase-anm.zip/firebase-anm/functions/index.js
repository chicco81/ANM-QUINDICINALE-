const {onRequest} = require("firebase-functions/v2/https");
const {defineSecret} = require("firebase-functions/params");
const fetch = (...args) => import("node-fetch").then(({default: f}) => f(...args));

// La chiave API viene salvata come Secret su Firebase (non nel codice)
const ANTHROPIC_KEY = defineSecret("ANTHROPIC_API_KEY");

exports.analizzaQuindicinale = onRequest(
  {secrets: [ANTHROPIC_KEY], cors: true, maxInstances: 10},
  async (req, res) => {

    // Solo POST
    if (req.method !== "POST") {
      res.status(405).json({error: "Metodo non consentito"});
      return;
    }

    try {
      const {imageBase64, mediaType} = req.body;

      if (!imageBase64 || !mediaType) {
        res.status(400).json({error: "Parametri mancanti: imageBase64 e mediaType obbligatori"});
        return;
      }

      // Valida media type
      const tipiAccettati = ["image/jpeg","image/png","image/webp","image/gif"];
      if (!tipiAccettati.includes(mediaType)) {
        res.status(400).json({error: "Tipo file non supportato. Usa JPG, PNG, WebP."});
        return;
      }

      const SYSTEM = `Sei un sistema esperto di quindicinali ANM (Azienda Napoletana Mobilità).

REGOLA CRITICA - NON SBAGLIARE MAI:
- "Uscita monto" = ORARIO INIZIO TURNO (campo monto)
- "Smonto" = ORARIO FINE TURNO (campo smonto)
Non invertire mai questi due valori.

Analizza l'immagine ed estrai TUTTI i giorni del quindicinale.

TIPI TURNO:
- RIPOSO -> "riposo"
- RIPOSO COMPENSATIVO / RIP.COMP -> "riposo_comp"
- FERIE -> "ferie"
- MALATTIA -> "malattia"
- PERMESSO -> "permesso"
- FESTIVO -> "festivo"
- SPEZZATO APERTURA / SPEZ.AP -> "spezzato_ap"
- SPEZZATO CHIUSURA / SPEZ.CH -> "spezzato_ch"
- DISP. MATTINA -> "disp_mattina"
- DISP. SERALE -> "disp_serale"
- DISP. NOTTURNA -> "disp_notturna"
- tutto il resto -> "servizio"

Rispondi SOLO con JSON puro, senza backtick, senza testo aggiuntivo:
{"nome":null,"matricola":null,"periodo":"","giorni":[{"data":"DD/MM/YYYY","giorno":"LUN","tipo":"servizio","monto":"HH:MM","smonto":"HH:MM","linea":"","turno":"","localita":"","durata":"","note":""}],"avvertenze":[]}`;

      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": ANTHROPIC_KEY.value(),
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 4096,
          system: SYSTEM,
          messages: [{
            role: "user",
            content: [
              {
                type: "image",
                source: {type: "base64", media_type: mediaType, data: imageBase64},
              },
              {
                type: "text",
                text: "Estrai tutti i turni da questa immagine. Uscita monto=INIZIO, Smonto=FINE. Rispondi solo JSON.",
              },
            ],
          }],
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        console.error("Errore API Anthropic:", data);
        res.status(502).json({error: "Errore API: " + (data?.error?.message || "sconosciuto")});
        return;
      }

      // Estrai testo
      const rawText = (data.content || [])
        .filter((b) => b.type === "text")
        .map((b) => b.text)
        .join("")
        .trim();

      if (!rawText) {
        res.status(502).json({error: "Risposta AI vuota"});
        return;
      }

      // Pulisci e parsa JSON
      let jsonText = rawText
        .replace(/^```json\s*/i, "")
        .replace(/^```\s*/, "")
        .replace(/\s*```$/, "")
        .trim();

      if (!jsonText.startsWith("{")) {
        const idx = jsonText.indexOf("{");
        if (idx >= 0) jsonText = jsonText.substring(idx);
      }
      jsonText = jsonText.substring(0, jsonText.lastIndexOf("}") + 1);

      let parsed;
      try {
        parsed = JSON.parse(jsonText);
      } catch (e) {
        res.status(502).json({error: "JSON non valido dalla risposta AI: " + e.message});
        return;
      }

      if (!parsed.giorni || !Array.isArray(parsed.giorni)) {
        res.status(502).json({error: "Nessun giorno trovato nell immagine"});
        return;
      }

      res.json(parsed);
    } catch (err) {
      console.error("Errore interno:", err);
      res.status(500).json({error: "Errore interno: " + err.message});
    }
  }
);
